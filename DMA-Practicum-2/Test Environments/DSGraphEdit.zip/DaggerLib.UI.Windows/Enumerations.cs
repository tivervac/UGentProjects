using System;
using System.Collections.Generic;
using System.Text;

namespace DaggerLib.UI.Windows
{
    public enum PinToolTipStyle
    {
        Name,
        NameShortType,
        NameLongType
    }
}
