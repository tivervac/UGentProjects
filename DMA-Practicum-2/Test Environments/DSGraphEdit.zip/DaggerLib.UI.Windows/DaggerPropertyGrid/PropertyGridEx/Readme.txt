From the article:	Add Custom Properties to a PropertyGrid (http://www.codeproject.com/vb/net/PropertyGridEx.asp)
					by Danilo Corallo.