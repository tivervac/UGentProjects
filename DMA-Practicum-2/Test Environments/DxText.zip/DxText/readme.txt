/************************************************************************

DirectShowLib - Provide access to DirectShow interfaces via .NET
Copyright (C) 2005
http://sourceforge.net/projects/directshownet/

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

**************************************************************************/

A sample application showing how to superimpose text strings on a
datastream.  The stream is read from an avi file.
 
	Written by Richard L Rosenheim
		richard@rosenheims.com
		May 21, 2005

Based in a large part upon the DxScan and DxPlayer samples by David Wohlferd

Portions Copyright 2004 - David Wohlferd david@LimeGreenSocks.com
Portions Copyright 2005 - Richard L Rosenheim
---------------------------------------------------------------------
